/*
 * PlotSquared, a land and world management plugin for Minecraft.
 * Copyright (C) IntellectualSites <https://intellectualsites.com>
 * Copyright (C) IntellectualSites team and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package com.plotsquared.bukkit.managers;

/*
import com.google.inject.Singleton;
import org.bukkit.World;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.Nullable;
import se.hyperver.hyperverse.Hyperverse;
import se.hyperver.hyperverse.world.WorldConfiguration;
import se.hyperver.hyperverse.world.WorldConfigurationBuilder;
import se.hyperver.hyperverse.world.WorldFeatures;
import se.hyperver.hyperverse.world.WorldType;

Hyperverse implementation is currently put on ice until Hyperverse is released on a stable line and deployed to the central
repository.

@Singleton
public class HyperverseWorldManager extends BukkitWorldManager {

    @Override
    public @Nullable World handleWorldCreation(@NonNull String worldName, @Nullable String generator) {
        // First let Bukkit register the world
        this.setGenerator(worldName, generator);
        // Create the world
        final WorldConfigurationBuilder worldConfigurationBuilder = WorldConfiguration.builder()
                .setName(worldName).setType(WorldType.OVER_WORLD);
        if (generator != null) {
            worldConfigurationBuilder.setGenerator(generator).setWorldFeatures(WorldFeatures.FLATLAND);
        }
        try {
            return Hyperverse.getApi().createWorld(worldConfigurationBuilder.createWorldConfiguration())
                    .getBukkitWorld();
        } catch (final Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public String getName() {
        return "bukkit-hyperverse";
    }

}
 */
